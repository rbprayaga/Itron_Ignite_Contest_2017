###########################################################################################################
# Program to Simulate the data push of Power outage Start time and End time in single HTML Request        #
###########################################################################################################
import xml.etree.ElementTree as ET
import urllib2
import sqlite3
from datetime import datetime
import time
import os

_cached_stamp = 0
# Read Configuration File to get the values from xml file
tree = ET.parse('config.xml')
doc = tree.getroot()
url = doc.find('url')
datafilename = doc.find('datafilename')
datafilepath = doc.find('datafilepath')
interval = doc.find('interval')

datafilepathtext = datafilepath.text
datafilenametext = datafilename.text
urltext = url.text
intervaltext = interval.text
fullpath = datafilepathtext + datafilenametext

print fullpath
print datafilepathtext
print datafilenametext
print urltext
print intervaltext


while 1:
	time.sleep(int(intervaltext))
	stamp = os.stat(datafilenametext).st_mtime
	if stamp != _cached_stamp:
		_cached_stamp = stamp
		#Loop the file for number of line times. 
		tree = ET.parse('data.xml')
		root = tree.getroot()
		for item in root.iter('item'):
		   starttime = item.find('StartTime').text
		   starttime = datetime.strptime(starttime[0:18], "%Y-%m-%d %H:%M:%S")
		   starttime = starttime.strftime("%m%d%Y-%H:%M:%S")  #Convert from %Y-%m-%d %H:%M:%S to %m%d%Y-%H:%M:%S
		   print starttime  #Print start time after conversion
		   print "Push outage Start time to cloud"
		   httprequest = urltext+'?LONGITUDE='+item.find('Longitude').text+'&LATITUDE='+item.find('Latitude').text+'&FEATUREKEY='+item.find('servicepoint').text+'&STARTTIME='+starttime   #Push Start time
		   print httprequest
		   response = urllib2.urlopen(httprequest)
		   html = response.read()
		   print html  #Get Response from Server
		#Sleep for 5 seconds until pushing the Outage end time.. This is used only for testing purpose. 
		   time.sleep(int(intervaltext))
		   print "Push outage End time to cloud"
		   endtime = item.find('EndTime').text
		   endtime = datetime.strptime(endtime[0:18], "%Y-%m-%d %H:%M:%S") #Convert from %Y-%m-%d %H:%M:%S to %m%d%Y-%H:%M:%S
		   endtime = endtime.strftime("%m%d%Y-%H:%M:%S")
		   print endtime
		   httprequest = urltext+'?LONGITUDE='+item.find('Longitude').text+'&LATITUDE='+item.find('Latitude').text+'&FEATUREKEY='+item.find('servicepoint').text+'&STARTTIME='+starttime+'&ENDTIME='+endtime      #Push End time                                                                           
		   print httprequest
		   response = urllib2.urlopen(httprequest)
		   html = response.read()
		   print html    #Get Response from Server
###########################################################################################################
#                                         END OF TEST PROGRAM                                             #
###########################################################################################################



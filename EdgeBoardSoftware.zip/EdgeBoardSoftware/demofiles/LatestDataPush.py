###################################################################################################################################
# Program to Find the new entry of Simulate the data push of Power outage Start time and End time in single HTML Request          #
###################################################################################################################################

import urllib2
import sqlite3
import time
from datetime import datetime
Checkendtime = [] 
conn = sqlite3.connect('TEST')
print conn

preLineCount=0
with open('DataSimulation.txt','rb') as f:                       
        for line in f:                                                      
           preLineCount+=1                      
print preLineCount  

################################################################################################################
#            Read data from DataSimulator.txt and Find the new entry and Push new entry of the data to cloud   #
#      Start outage time and End outage time will be pushed in single HTML Resqest                             #
################################################################################################################
while True:
	time.sleep(5)
	curLineCount=0
	with open('DataSimulation.txt','rb') as f:                       
       	 for line in f:                                                      
           curLineCount+=1   
	checkLineCount = curLineCount - preLineCount   
	if preLineCount == curLineCount:
		print "No new Data Logged in the file and " + " Line count is" 
		print curLineCount
		print "\n"

	if checkLineCount == 1:
		print "Read the last line added\n"
		f=open('DataSimulation.txt')
		lines=f.readlines()
		print lines[curLineCount-1]
		values = lines[curLineCount-1].split("\t")
		length = len(values)
		print length
		if length == 6:
			preLineCount = curLineCount
			starttime = datetime.strptime(values[4], "%Y-%m-%d %H:%M:%S")
			starttime = starttime.strftime("%m%d%Y-%H:%M:%S")
			print starttime
			endtime = values[5]
			endtime = datetime.strptime(endtime[0:18], "%Y-%m-%d %H:%M:%S")
			endtime = endtime.strftime("%m%d%Y-%H:%M:%S")
			print endtime		
			httprequest = 'https://gridevents.cyient-fiops.com:8084/POWEROUTAGE/?LONGITUDE='+values[2]+'&LATITUDE='+values[1]+'&FEATUREKEY='+values[0]+'&STARTTIME='+starttime+'&ENDTIME='+endtime
			print httprequest
#############################################################################################################################################
#            Find the new entry only Start outage time Push new entry of the data to cloud as saperate  #
#                       request of Outage start time                             							    #
#############################################################################################################################################			
		elif length == 5:
			print "Send only the Power Outage Start time\n"
			preLineCount = curLineCount
			starttime = values[4]
			starttime = datetime.strptime(starttime[0:18], "%Y-%m-%d %H:%M:%S")
			starttime = starttime.strftime("%m%d%Y-%H:%M:%S")
			print starttime
			httprequest = 'https://gridevents.cyient-fiops.com:8084/POWEROUTAGE/?LONGITUDE='+values[2]+'&LATITUDE='+values[1]+'&FEATUREKEY='+values[0]+'&STARTTIME='+starttime
			print httprequest
			

	elif checkLineCount > 1:
		print "do nothing for now"
	                 
	
###########################################################################################################
#                                         END OF TEST PROGRAM                                             #
###########################################################################################################




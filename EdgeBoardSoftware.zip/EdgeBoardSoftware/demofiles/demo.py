###########################################################################################################
# Program to Simulate the data push of Power outage Start time and End time in single HTML Request        #
###########################################################################################################

import urllib2
import sqlite3
from datetime import datetime
import time

#conn = sqlite3.connect('TEST')  #Connect to Database This is currently Not used. 

###########################################################################################################
#            Read data from DataSimulator.txt and Push the data to cloud                                  #
#      Start outage time and End outage time will be pused in single HTML Resqest                         #
###########################################################################################################

#Loop the file for number of line times. 
for line in open('DataSimulation.txt').xreadlines():
   values = line.split("\t")
   starttime = values[4]
   starttime = datetime.strptime(starttime[0:18], "%Y-%m-%d %H:%M:%S")
   starttime = starttime.strftime("%m%d%Y-%H:%M:%S")  #Convert from %Y-%m-%d %H:%M:%S to %m%d%Y-%H:%M:%S
   print starttime  #Print start time after conversion
   endtime = values[5]
   endtime = datetime.strptime(endtime[0:18], "%Y-%m-%d %H:%M:%S") #Convert from %Y-%m-%d %H:%M:%S to %m%d%Y-%H:%M:%S
   endtime = endtime.strftime("%m%d%Y-%H:%M:%S")
   print endtime
   httprequest = 'https://gridevents.cyient-fiops.com:8084/POWEROUTAGE/?LONGITUDE='+values[2]+'&LATITUDE='+values[1]+'&FEATUREKEY='+values[0]+'&STARTTIME='+starttime+'&ENDTIME='+endtime
   print httprequest
   response = urllib2.urlopen(httprequest)
   html = response.read()
   print html  #Get Response from Server
###########################################################################################################
#                                         END OF TEST PROGRAM                                             #
###########################################################################################################



﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cyient.PowerOutage.Models
{
    public class OutageModel : BindableBase
    {
        public OutageModel()
        {

        }

        private decimal _outageKey;
        public decimal OutageKey
        {
            get
            {
                return _outageKey;
            }
            set
            {
                SetProperty(ref _outageKey, value);
            }
        }

        private string _servicePointId;
        public string ServicePointId
        {
            get
            {
                return _servicePointId;
            }
            set
            {
                SetProperty(ref _servicePointId, value);
            }
        }

        private decimal? _nominalVoltage;
        public decimal? NominalVoltage
        {
            get
            {
                return _nominalVoltage;
            }
            set
            {
                SetProperty(ref _nominalVoltage, value);
            }
        }

        private string _transformerId;
        public string TransformerId
        {
            get
            {
                return _transformerId;
            }
            set
            {
                SetProperty(ref _transformerId, value);
            }
        }

        private string _address1;
        public string Address1
        {
            get
            {
                return _address1;
            }
            set
            {
                SetProperty(ref _address1, value);
            }
        }

        private string _address2;
        public string Address2
        {
            get
            {
                return _address2;
            }
            set
            {
                SetProperty(ref _address2, value);
            }
        }

        private decimal? _latitude;
        public decimal? Latitude
        {
            get
            {
                return _latitude;
            }
            set
            {
                SetProperty(ref _latitude, value);
            }
        }

        private decimal? _longitude;
        public decimal? Longitude
        {
            get
            {
                return _longitude;
            }
            set
            {
                SetProperty(ref _longitude, value);
            }
        }

        private DateTime? _startTime;
        public DateTime? StartTime
        {
            get
            {
                return _startTime;
            }
            set
            {
                SetProperty(ref _startTime, value);
            }
        }

        private DateTime? _endTime;
        public DateTime? EndTime
        {
            get
            {
                return _endTime;
            }
            set
            {
                SetProperty(ref _endTime, value);
            }
        }

        private bool _isActive;
        public bool IsActive
        {
            get
            {
                return _isActive;
            }
            set
            {
                SetProperty(ref _isActive, value);
            }
        }

    }
}

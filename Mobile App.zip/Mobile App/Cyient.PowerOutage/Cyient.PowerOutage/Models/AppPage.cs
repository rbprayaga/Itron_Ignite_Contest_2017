﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cyient.PowerOutage.Models
{
    public enum AppPage
    {
        OutageDetails,
        OutageMap,
        ReportOutage
        //Events,
        //MiniHacks,
        //Sponsors,
        //Venue,
        //FloorMap,
        //ConferenceInfo,
        //Settings,
        //Session,
        //Speaker,
        //Sponsor,
        //Login,
        //Event,
        //Notification,
        //TweetImage,
        //WiFi,
        //CodeOfConduct,
        //Filter,
        //Information,
        //Tweet,
        //Evals
    }
}

﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cyient.PowerOutage.Models
{
    public class MasterPageItem : BindableBase
    {


        private string _menuName;
        public string MenuName
        {
            get
            {
                return _menuName;
            }
            set
            {
                SetProperty(ref _menuName, value);
            }
        }
        private string _iconName;
        public string IconName
        {
            get
            {
                return _iconName;
            }
            set
            {
                SetProperty(ref _iconName, value);
            }
        }



        public MasterPageItem()
        {


        }

    }
}

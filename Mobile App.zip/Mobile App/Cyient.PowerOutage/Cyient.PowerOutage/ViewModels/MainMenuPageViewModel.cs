﻿using Cyient.PowerOutage.Models;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace Cyient.PowerOutage.ViewModels
{
    public class MainMenuPageViewModel :BindableBase
    {
        INavigation _navigation;
        public MainMenuPageViewModel(INavigation navigation)
        {
            _navigation = navigation;
            AddMenus();
        }

        private ObservableCollection<MasterPageItem> _menuCollection;
        public ObservableCollection<MasterPageItem> MenuCollection
        {
            get
            {
                return _menuCollection;
            }
            set
            {
                SetProperty(ref _menuCollection, value);
            }
        }

        private void AddMenus()
        {
            if (MenuCollection != null)
            {
                MenuCollection.Clear();
            }
            else
            {
                MenuCollection = new ObservableCollection<MasterPageItem>();
            }

            MenuCollection.Add(new MasterPageItem() { IconName = "account.png", MenuName = "My Account" });
            MenuCollection.Add(new MasterPageItem() { IconName = "ic_home_black_18dp.png", MenuName = "Home" });
            MenuCollection.Add(new MasterPageItem() { IconName = "map.png", MenuName = "Outage Map" });
            MenuCollection.Add(new MasterPageItem() { IconName = "ic_flash_black_18dp.png", MenuName = "Report Outage" });
            MenuCollection.Add(new MasterPageItem() { IconName = "settings.png", MenuName = "Settings" });
            MenuCollection.Add(new MasterPageItem() { IconName = "alerts.png", MenuName = "Alerts" });
            MenuCollection.Add(new MasterPageItem() { IconName = "signout.png", MenuName = "Sign Out" });
        



        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Cyient.PowerOutage.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OutageDetailsPage : ContentPage
	{
		public OutageDetailsPage()
		{
			InitializeComponent ();

            BindingContext = new ViewModels.OutageDetailsPageViewModel(Navigation);

           // var normalFab = new FAB.Forms.FloatingActionButton();
           // normalFab.Source = "ic_plus_white_18dp.png";
           // normalFab.Size = FabSize.Normal;
           //// relativeLayout.Children.Add(normalFab);
            

           // relativeLayout.Children.Add(
           //     normalFab,
           //     xConstraint: Constraint.RelativeToParent((parent) => { return (parent.Width - normalFab.Width) - 16; }),
           //     yConstraint: Constraint.RelativeToParent((parent) => { return (parent.Height - normalFab.Height) - 16; })
           // );

        }
	}
}

﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cyient.PowerOutage.ViewModels
{
    public class LogInPageViewModel: BindableBase
    {
        INavigation _navigation;
        public LogInPageViewModel(INavigation navigation)
        {
            _navigation = navigation;
        }

    }
}

﻿using Esri.ArcGISRuntime.Mapping;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cyient.PowerOutage.ViewModels
{
    public class ReportOutageViewModel : BindableBase
    {
        #region Private Variables
            INavigation _navigation;

        #endregion

        #region Properties
        private Map _currentMap = null;
        public Map CurrentMap
        {
            get
            {
                return _currentMap;
            }
            set
            {
              SetProperty(ref _currentMap, value, "CurrentMap");
            }
        }

        #endregion
        public ReportOutageViewModel(INavigation navigation)
        {
            _navigation = navigation;
            LoadMap();

        }

        public void LoadMap()
        {
            string portalid = "http://www.arcgis.com/home/item.html?id=88eaca5a82734c92bee08b235a2dfc6b";

            CurrentMap = new Map(new Uri(portalid));
        }
    }
}

﻿using Cyient.PowerOutage.Models;
using MvvmHelpers;
using Newtonsoft.Json;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Cyient.PowerOutage.ViewModels
{

    public class OutageDetailsPageViewModel : BindableBase
    {
        INavigation _navigation;
        private ObservableRangeCollection<OutageModel> _outageCollection;
        public ObservableRangeCollection<OutageModel> OutageCollection
        {
            get
            {
                return _outageCollection;
            }
            set
            {
                SetProperty(ref _outageCollection, value);
            }
        }
        private string _filter;
        public string Filter
        {
            get
            {
                return _filter;
            }
            set
            {
                SetProperty(ref _filter, value);
            }
        }

        public DelegateCommand RefreshOutageCommand { get; private set; }

        public DelegateCommand FilterOutageCommand { get; private set; }
        public DelegateCommand<object> ViewMapDetailsCommand { get; private set; }

        public OutageDetailsPageViewModel(INavigation navigation)
        {
            RefreshOutageCommand = new DelegateCommand(GetOutageData);
            FilterOutageCommand = new DelegateCommand(ExecuteFilterOutage);
            ViewMapDetailsCommand = DelegateCommand<object>.FromAsyncHandler(ShowMapDetails);

            _navigation = navigation;
            InitializeVariables();
            GetOutageData();

             
            //CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(SoftwarePatchesCollection);
            //view.SortDescriptions.Add(new SortDescription("ServerName", ListSortDirection.Descending));


        }

        private void InitializeVariables()
        {
            OutageCollection = new ObservableRangeCollection<OutageModel>();
        }

        private void ExecuteFilterOutage()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selectedItem"></param>
        /// <returns></returns>
        private async Task ShowMapDetails(object selectedItem)
        {
            var item = selectedItem as Models.OutageModel;

            NavigationPage navPage = new NavigationPage(new Views.OutageMapPage());

            await _navigation.PushModalAsync(navPage);
        }
        private void GetOutageData()
        {
            if (OutageCollection != null)
            {
                OutageCollection.Clear();
            }
            else
            {
                OutageCollection = new ObservableRangeCollection<OutageModel>();
            }
            System.Net.WebClient outageClient  = new System.Net.WebClient();

            outageClient.DownloadStringCompleted += (s, e) =>
            {
                OutageClient_DownloadStringCompleted(e);
            };

           // outageClient.DownloadStringCompleted += OutageClient_DownloadStringCompleted;

            outageClient.DownloadStringAsync(new Uri("https://www.cyient-fiops.com/IOTService/api/outages"));
        }

        private void OutageClient_DownloadStringCompleted( System.Net.DownloadStringCompletedEventArgs e)
        {
            try
            {
                if (e.Error == null)
                {
                    var outageList = JsonConvert.DeserializeObject<List<OutageModel>>(e.Result);
                    if (outageList != null && outageList.Count > 0)
                    {
                        foreach (var outage in outageList)
                        {
                            OutageCollection.Add(outage);
                        }
                    }
                }
   
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        

        //private void OutageClient_DownloadStringCompleted(object sender, System.Net.DownloadStringCompletedEventArgs e)
        //{
        //    try
        //    {
        //        if (e.Error == null)
        //        {
        //            var outageList = JsonConvert.DeserializeObject<List<OutageModel>>(e.Result);
        //            if (outageList != null && outageList.Count > 0)
        //            {
        //                foreach (var outage in outageList)
        //                {
        //                    OutageCollection.Add(outage);
        //                }
        //            }
        //        }
                


        //    }
        //    catch (Exception ex)
        //    {
        //         throw ex;
        //    }
           
        //}
    }
}

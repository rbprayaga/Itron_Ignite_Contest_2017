﻿using Esri.ArcGISRuntime.Mapping;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace Cyient.PowerOutage.ViewModels
{
   public  class OutageMapPageViewModel :BindableBase
    {
        INavigation _navigation;

        #region Properties
        private Map _currentMap = null;
        public Map CurrentMap
        {
            get
            {
                return _currentMap;
            }
            set
            {
                SetProperty(ref _currentMap, value, "CurrentMap");
            }
        }

        #endregion

        public OutageMapPageViewModel(INavigation navigation)
        {
            _navigation = navigation;

            LoadMap();

        }
        public void LoadMap()
        {
              string portalid = "http://www.arcgis.com/home/item.html?id=88eaca5a82734c92bee08b235a2dfc6b";

           // string portalid = "http://www.arcgis.com/home/item.html?id=01f052c8995e4b9e889d73c3e210ebe3";

            CurrentMap = new Map(new Uri(portalid));
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Cyient.PowerOutage.Views
{
	public partial class MainMenuPage : ContentPage
	{
        HomePage root; 
        public MainMenuPage (HomePage root)
		{
            this.root = root;

            InitializeComponent ();
            BindingContext = new ViewModels.MainMenuPageViewModel(Navigation);

            menuListView.ItemSelected += MenuListView_ItemSelected;

        }

        private async void MenuListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            await Task.Delay(225);
            Models.MasterPageItem rpOutage = e.SelectedItem as Models.MasterPageItem;
            switch (rpOutage.MenuName)
            {
                case "Outage Map":
                    await this.root.NavigateAsync(1);
                    break;
                case "Report Outage":
                    await this.root.NavigateAsync(2);
                    break;
                case "Home":
                    await this.root.NavigateAsync(0);
                    break;
            }
          
       
        }
    }
}

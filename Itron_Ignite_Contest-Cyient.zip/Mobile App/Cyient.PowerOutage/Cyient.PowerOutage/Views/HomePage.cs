﻿using Cyient.PowerOutage.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Cyient.PowerOutage.Views
{
    public class HomePage : MasterDetailPage
    {
        Dictionary<int, NavigationPage> pages;

        public HomePage()
        {
            this.Icon = null;


            pages = new Dictionary<int, NavigationPage>();

            Master = new MainMenuPage(this);
            // Detail = new OutageDetailsPage();
            NavigationPage navPage = new NavigationPage(new OutageDetailsPage());


            //#00a3cc
            navPage.BarBackgroundColor = Color.FromHex("#00a3cc");
            navPage.Icon = null;
            navPage.BackgroundImage = null;

            Detail = navPage;
          

            // Detail.BackgroundColor = Color.Blue;
            MasterBehavior = MasterBehavior.Popover;

            pages.Add(0,new NavigationPage(new OutageDetailsPage()));
            //pages.Add(1, new NavigationPage(new OutageMapPage()));
            //pages.Add(2, new NavigationPage(new ReportOutage()));





        }

        public async Task NavigateAsync(int menuId)
        {
             NavigationPage newPage = null;
            if (!pages.ContainsKey(menuId))
            {
                //only cache specific pages
                switch (menuId)
                {
                    case (int)AppPage.OutageMap: //Feed
                        newPage = new NavigationPage(new OutageMapPage());
                        break;
                    case (int)AppPage.ReportOutage://sessions
                        newPage = new NavigationPage(new ReportOutage());
                        break;
                    //case (int)AppPage.Events://events
                    //    pages.Add(menuId, new EvolveNavigationPage(new EventsPage()));
                    //    break;
                    //case (int)AppPage.MiniHacks://Mini-Hacks
                    //    newPage = new EvolveNavigationPage(new MiniHacksPage());
                    //    break;
                    //case (int)AppPage.Sponsors://sponsors
                    //    newPage = new EvolveNavigationPage(new SponsorsPage());
                    //    break;
                    //case (int)AppPage.Venue: //venue
                    //    newPage = new EvolveNavigationPage(new VenuePage());
                    //    break;
                    //case (int)AppPage.ConferenceInfo://Conference info
                    //    newPage = new EvolveNavigationPage(new ConferenceInformationPage());
                    //    break;
                    //case (int)AppPage.FloorMap://Floor Maps
                    //    newPage = new EvolveNavigationPage(new FloorMapsCarouselPage());
                    //    break;
                    //case (int)AppPage.Settings://Settings
                    //    newPage = new EvolveNavigationPage(new SettingsPage());
                    //    break;
                    //case (int)AppPage.Evals:
                    //    newPage = new EvolveNavigationPage(new EvaluationsPage());
                    //    break;
                }
            }

            if (newPage == null)
                newPage = pages[menuId];

            if (newPage == null)
                return;

            //if we are on the same tab and pressed it again.
            if (Detail == newPage)
            {
                await newPage.Navigation.PopToRootAsync();
            }
            newPage.BarBackgroundColor = Color.FromHex("#00a3cc");
            Detail = newPage;
           // Detail.Title = newPage.Title;
        }


    }
}

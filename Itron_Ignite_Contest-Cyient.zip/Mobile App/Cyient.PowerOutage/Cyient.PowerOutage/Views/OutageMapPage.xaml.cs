﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace Cyient.PowerOutage.Views
{
	public partial class OutageMapPage : ContentPage
	{
		public OutageMapPage ()
		{
			InitializeComponent ();
            BindingContext = new ViewModels.OutageMapPageViewModel(Navigation);
		}
	}
}
